import { initializeApp } from "firebase/app"
import { getAuth, GoogleAuthProvider } from "firebase/auth"
import { getFirestore } from "firebase/firestore"

const firebaseConfig = {
  apiKey: "AIzaSyD-2pG7WlgfZ82SE04wvTMLyEH8PZ_GAl0",
  authDomain: "vocab-app-4c6ab.firebaseapp.com",
  projectId: "vocab-app-4c6ab",
  storageBucket: "vocab-app-4c6ab.firebasestorage.app",
  messagingSenderId: "59114866617",
  appId: "1:59114866617:web:bde7190ec139a8f5779868",
}

const app = initializeApp(firebaseConfig)
export const auth = getAuth(app)
export const db = getFirestore(app)
export const googleProvider = new GoogleAuthProvider()
export const ADMIN_EMAILS = ["dodatphi@gmail.com"]
